var amount = 5;
while ( amount < 10) 
{alert(amount); amount++;}